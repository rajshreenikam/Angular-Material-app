import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'AngularMaterialProject';
  notifications=2;
  notifications1=0;
  showSpinner=false;
  opened=false;

  loadData(){
    this.showSpinner=true;
    setTimeout(()=>{
        this.showSpinner=false;
    },5000)
  }
}
